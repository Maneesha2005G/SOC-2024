#include<simplecpp>
main_program{
        int c[100];
        int n;
        cin >> n;
        for(int i=0;i<n;i++){
                cin >> c[i];
        }
        /* for(int i=0;i<n;i++){
                cout << c[i];
        }*/
        int t;
        cin >> t;
        for(int i=0;i<n;i++){
                for(int j=i;j<n;j++){
                        if((c[i]+c[j]==t) && (i!=j)){
                                cout << i << " " << j;
                        }
                        else{
                                continue;
                        }
                }
        }
}
