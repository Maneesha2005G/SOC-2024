#include<simplecpp>
main_program{
    	int n;
        cin >> n;
	int c[100];
        for(int i=0;i<n;i++){
                 cin >> c[i];
         }

        int a=0;
        int k;
        cin >> k;
        for(int i=0;i<n-k+1;i++){
                for(int j=i;j<i+k;j++){
                if(c[j]>a){
                        int t=c[j];
                        c[j]=a;
                        a=t;
                }
             }
             cout << a;
        }
}
