#include<simplecpp>
main_program{
	int c[100];
	int n;
	cin >> n;
	for(int i=1;i<n+1;i++){
		cin >> c[i];
	}
	/* for(int i=1;i<n+1;i++){
                cout << c[i];
        }*/
	int t;
	cin >> t;
	for(int i=1;i<n+1;i++){
		for(int j=i;j<n+1;j++){
			if((c[i]+c[j]==t) && (i!=j)){
				cout << i << " " << j;
			}
			else{
				continue;
			}
		}
	}
}
