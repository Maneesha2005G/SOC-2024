#include<simplecpp>
main_program{
	int a;
	cin >> a;
	int l=0;
	int bin[100];
	while(a>0){
		int c=a%2;
		bin[l]=c;
		a=a/2;
		l++;
	}
	
	/*for(int i=l-1;i>=0;i--){
		cout << bin[i];
	}*/
	int q=0;
	for(int i=0;i<l;i++){
		if(bin[i]==0){
			q++;
		}
	}
	cout << pow(2,q);
}
	
