#include<simplecpp>
main_program{
	char c[100];
	cin >> c;
	int l=0;
	while(c[l]!='\0'){
		l++;
	}
	int k;
	cin >> k;

	for(int i=0;i<l-k+1;i++){
		for(int j=i;j<i+k;j++){
                cout << c[j];
        }
		cout << " ";
	}

}
