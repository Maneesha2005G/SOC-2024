#include<simplecpp>
main_program{
	char c[100];
	cin >> c;
	int l=0;
	while(c[l]!='\0'){
		l++;
	}
	bool b=true;
	for(int i=0;i<l;i++){
		 if(c[i]=='('){
                        if(c[i+1]==')'){
                                continue;
                        }
                        else{
				b=false;
                                cout << "false";
                        }
		 }
	}
	if(b){
		cout << "true";
	}
}

