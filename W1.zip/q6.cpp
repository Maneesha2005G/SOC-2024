#include<simplecpp> 

void sort(int arr[],int n){
	if(n==0){
		return;
	}
	else{
		for(int i=0;i<n;i++){
			if(arr[i-1]>arr[i]){
				int temp=arr[i-1];
				arr[i-1]=arr[i];
				arr[i]=temp;
			}
		}
		sort(arr,n-1);
	}
}

main_program{
	int n;
	cin >> n;
	int arr[100];
	for(int i=0;i<n;i++){
		cin >> arr[i];
	}
	
	sort(arr,n);
	for(int i=0;i<n;i++){
                cout << arr[i] << endl;
        }
	cout << arr[0];
}
