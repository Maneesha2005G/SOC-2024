#include <simplecpp>
main_program{
	int n,k;
	cin >> n;
	int c[100];
	for(int i=1;i<n+1;i++){
		cin >> c[i];
	}
	cin >> k;
	int s=0;
	bool m=true;
	for(int i=1;i<n+1;i++){
		s=s+c[i];

		if(s>=k){
			m=false;
			cout << i;
		}
	}
	if(m){
		cout << "-1";
	}
}
