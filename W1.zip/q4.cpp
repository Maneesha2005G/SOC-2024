#include<simplecpp>
main_program{
	int n;
	cin >> n;
	int arr[100];
	for(int i=0;i<n;i++){
		cin >> arr[i];
	}
	int sum=0;
	for(int i=0;i<n;i++){
		int m=arr[i];
		for(int j=i+1;j<n;j++){
		m=m+arr[j];	
		if(m>sum){
		sum=m;
		}
		}
	}
	cout << sum;
	}
