#include <iostream>
using namespace std;

int main() {
    int t;
    cin >> t;  
    for (int tt = 0; tt < t; tt++) {
        int n, q;
        cin >> n >> q;
        int a[100];
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        for (int l = 0; l < q; l++) {
            int b, c;
            cin >> b >> c;
            int y = -1, z = -1;
            for (int i = 0; i < n; i++) {
                if (a[i] == b) {
                    y = i;
                }
                if (a[i] == c) {
                    z = i;
                }
            }
            if (y == -1 || z == -1) {
                cout << "NO" << endl;  
            } else if (y <= z) {
                cout << "YES" << endl;
            } else {
                cout << "NO" << endl;
            }
        }
    }
    return 0;
}

