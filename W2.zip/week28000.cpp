#include <iostream>
using namespace std;

bool isValid(char s[], int n, int length) {
    int d = 0;
    for (int i = 0; i < n; i++) {
        if (s[i] != s[i % length]) {
            d++;
            if (d > 1) {
                return false;
            }
        }
    }
    return true;
}

int main() {
    int t;
    cin >> t;  
    while (t--) {
        int n;
        cin >> n;
        char s[1000];
        cin >> s;
        for (int l = 1; l <= n; l++) {
            if (isValid(s, n, l)) {
                cout << l << endl;
                return 0;  
            }
        }
    }
    return 0;
}

